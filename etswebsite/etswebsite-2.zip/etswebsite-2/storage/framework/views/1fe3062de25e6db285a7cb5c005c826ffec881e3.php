<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Buon Viaggio</title>
        <link rel="icon" type="image/png" href="favicon.png">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        
        <style type = "text/css">
            #header{
                background-color: #0E288F;
                color: #ffffff;
                text-align: center;
            }

            a:link{color: #ffffff;}
            a:visited{color: #ffffff;}
            a:hover{color: #ffffff}
            a:active{color: #ffffff;}

        </style>
    </head>
    <body style="background-color: #81BCFF;">
        <div style="background-color: #0E288F">
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <p style="text-align: right;">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 underline">Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <div id="header">
            <br>
                <h1>Buon Viaggio</h1>
                <h4>Book your vehicles to tour here</h4>
            <br>


            <br>
            <a href="order.blade.php">Book</a>
            <br>
            <br>
            <a href="car_list.blade.php">Car List</a>
            <br>
            <br>
            <a href="package_reccommendation.php">Recommendations</a>
            <br>
            <br>
            <a href="promotion_package.blade.php">Promotion</a>
            <br>
            <br>
            <a href="">Contact</a>
            <br>
            <br><br>
        </div>

        <div>
            
        </div>

                    <div class="ml-4 text-center text-sm text-gray-500 sm:text-right sm:ml-0">
                        Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\etswebsite\resources\views/welcome.blade.php ENDPATH**/ ?>