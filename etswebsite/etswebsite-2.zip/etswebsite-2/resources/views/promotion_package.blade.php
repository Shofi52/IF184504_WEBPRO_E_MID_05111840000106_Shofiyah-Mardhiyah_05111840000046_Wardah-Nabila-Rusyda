<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buon Viaggio</title>
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style type = "text/css">
        #header{
            background-color: #0E288F;
            color: #ffffff;
            text-align: center;
        }
        #body{
            padding: 5vw;
        }
        a:link{color: #ffffff;}
        a:visited{color: #ffffff;}
        a:hover{color: #ffffff}
        a:active{color: #ffffff;}

    </style>
</head>
<body style="background-color: #81BCFF;"> 
     <div id="header">
      <p style="text-align: left;">
        <a href=""></a> &nbsp;&nbsp;&nbsp; Back </p>
        <br>
        <h1>Buon Viaggio</h1>
        <h4>Promotion Package</h4>
        <br><br><br>
     </div>
      
   <div id="body">
    <div class="row">
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Promo 1</h5>
              <p class="card-text">Opening promotion: <br> 
            <ul>
              <li>Car: Fortuner 2010 – 2015</li>
             <li>Rent 2 for Rp. 1.500.000/day </li>
             <li>Usual price: Rp. 1.000.000/day for 1 car</li>    
            </ul></p>
            <a href="" class="btn btn-primary">Book Now</a>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"></h5><br><br>
              <h4 class="card-title" style="color: gray; text-align: center">COMING SOON</h4><br><br>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title"></h5><br><br>
                <h4 class="card-title" style="color: gray; text-align: center">COMING SOON</h4><br><br>
              </div>
            </div>
          </div>
      </div>
   </div>
    
</body>
</html>