<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buon Viaggio</title>
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style type = "text/css">
        #header{
            background-color: #0E288F;
            color: #ffffff;
            text-align: center;
        }
        #body{
            padding: 5vw;
        }
        a:link{color: #ffffff;}
        a:visited{color: #ffffff;}
        a:hover{color: #ffffff}
        a:active{color: #ffffff;}

    </style>
</head>
<body style="background-color: #81BCFF;"> 
     <div id="header">
        <p style="text-align: left;">
            <a href="welcome.blade.php"></a> &nbsp;&nbsp;&nbsp; Back
        </p>
        <br>
        <h1>Buon Viaggio</h1>
        <h4>Car List</h4>
        <br><br><br>
     </div>
      
   <div id="body">
    <div class="row">
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Fortuner 2010–2015</h5>
              <p class="card-text">type: SUV <br>
                Seats: 7  <br>
                Price: Rp. 1.000.000/day
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body">
                <h5 class="card-title">Fortuner VRZ 2016 – 2019</h5>
                <p class="card-text">type: SUV <br>
                  Seats: 7  <br>
                  Price: Rp. 1.300.000/day
            </div>
          </div>
        </div>
        <div class="col-sm-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Pajero 2016 – 2019</h5>
              <p class="card-text">type: SUV <br>
                Seats: 7  <br>
                Price: Rp. 1.300.000/day
              </div>
            </div>
          </div>
      </div>
   </div>
    
</body>
</html>